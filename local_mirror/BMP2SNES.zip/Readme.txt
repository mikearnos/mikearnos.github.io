MopoZ aka gegmopo3 2013
BMP2SNES v1.0

Use this software to convert the image format *.BMP with no compression.
Can be used formats and 8 and 4bpp. Just is convecting palette image.
Picture resolution can exceed 256x224 and be less.